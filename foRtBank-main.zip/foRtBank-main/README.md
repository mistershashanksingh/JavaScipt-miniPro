# foRtBank
web-technology
1. Download zip or clone git repo.
2. pre req:- editor -vscode, browser -edge.
if guys need to add php can do because xampp or php admin is not gonna provide by my fucking college so i.e. ivn't add.
